package com.company;

public class Pair {
    public Move move = null;
    public int value = 0;

    public Pair(Move move, int value) {
        this.move = move;
        this.value = value;
    }

}
